package com.chromeinfotech.navigationdrawer;

/**
 * Created by user on 13/4/17.
 */

public class DataModel {
    public int icon;
    public String name;


    // Constructor.
    public DataModel(int icon, String name) {

        this.icon = icon;
        this.name = name;
    }
}
